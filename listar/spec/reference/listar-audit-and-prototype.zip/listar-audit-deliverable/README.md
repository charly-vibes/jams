# Listar source audit + minimal semantic prototype

Read `REPORT.md` first. `transition.mjs` is an independent prototype; it is not wired into the Jams PWA. `transition.test.mjs` contains ten executable examples and can be run with `node --test transition.test.mjs` (Node >=18). `splitter-baseline.js` is copied from the user-uploaded source as a reference; no changes were made to the source repository.
