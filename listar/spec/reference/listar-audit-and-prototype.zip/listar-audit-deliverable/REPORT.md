# Listar implementation audit and categorical-model simplification

Date: 2026-10-29. Source: user-uploaded `jams-main.zip`, `jams-main/listar`. Spec: user-uploaded validated Specodelic pack. No changes made to original application.

## Reproduction

- `cd jams-main/listar && node --test test/splitter.test.js`: **41/41 passing**.
- `cd jams-main/listar && node --test test/*.test.js`: splitter 41 passing, DB suite failed to load because `fake-indexeddb` absent. `npm ci --offline` failed because the package was not cached. Database application behavior was **not** independently tested.
- `node --test transition.test.mjs` inside this bundle: **10/10 passing**. This is an exploratory semantic reference implementation, not production integration.
- Prior `spk` validation of the supplied spec pack: 5 lint clean; graph and compile pass; model-check exploration only; 24 semantic claims unchecked. No categorical proof is claimed.

## Source-level facts

- `splitter.js`: pure `split(transcript)` ESM, with numbered/bullet/line segmentation, connector heuristics, Spanish number-unit extraction and transcript-local duplicate merging. Existing tests contain 41 cases. Merge logic matches lowercase labels and exact units, sums quantities, and retains only the first raw `text`; provenance of later duplicate mentions is not preserved.
- `db.js`: IndexedDB schema v1 with `lists`, `items`, `audio`. `Item` already contains stable `id`, `listId`, `label`, `text`, optional `quantity`/`unit`, `done`, `order`, and optional `sourceAudioId`. `Item.put(rec)` can technically store additional serializable fields without immediate schema migration, but validators, indexes, adapters, and UI assumptions must be checked before relying on this. No durable command log, list snapshot version, or atomic operation reducer is implemented.
- `spec/functionality.md`: originally conceived as append-only recordings with confirmation preview; existing splitter strategy contract returns an array of parsed items. It specifies a zero-build client-side PWA. A separate semantic analysis method should be added without breaking this contract.
- Uploaded archive contains only `listar/db.js`, `splitter.js`, tests, package metadata and specs within the `listar/` directory; no `listar/script.js`, `index.html` or worker. Consequently actual Listar UI wiring, preview interactions and end-to-end browser behavior were not audited.

## Categorical model challenged against real code

| Distinction | Evidence | Decision |
|---|---|---|
| List vs Entry | Existing `listId` and stable item IDs | **Keep, already implemented** |
| Entry vs ProductRef | Identical labels can be distinct entries; no product catalog exists | **Keep item ID, defer separate ProductRef table** |
| Attribute vs Assertion | Price observation and budget constraint are semantically different | **Start with typed inline attribute records with `role`, defer separate Assertion table** |
| Evidence | `text`, `sourceAudioId` existing; merge loses secondary text | **Preserve source spans or source mentions for new candidate operations** |
| Command vs Entry | `otro litro` vs `poné dos litros`, read-only questions | **Introduce explicit command candidates and pure reducer** |
| Snapshot | Retry and stale context can double-apply | **Introduce version and operation ID for commits** |
| Candidate vs committed command | Ambiguity and model uncertainty | **Keep candidate interpretations separate from reducer** |

## Law/counterexample results

The experimental `transition.mjs` validates: migration retraction (`legacyView(migrate(x))=x`), query and noop state identities, replay idempotence for a committed increment, stale snapshot rejection, failure atomicity for incompatible units, distinct IDs with identical labels, separation of price observation from a price constraint, invalid price basis rejection, and commutativity of independent attribute updates on the *item projection*. All ten tests pass. These are examples, not universal proofs; no calibrated NLP confidence model was implemented.

## Architecture that appears sufficient for first implementation

`transcript + listSnapshot -> analyze -> proposed commands -> preview -> apply(commands, version) -> persisted state`

Keep `split(transcript)` as legacy compatibility path. New `analyze(transcript, context)` returns candidate commands plus diagnostics and evidence. `apply` is a pure deterministic and tested reducer. IndexedDB owns transactions and version checking; do not pretend a pure reducer alone gives durable exactly-once semantics. On commit, the version guard and operation journal must be persisted in *one IndexedDB readwrite transaction*. Avoid false global probabilistic confidence: calibrate only after outcome labels exist. Add CRF/WASM/LLM only if failure analysis requires them.

## Open risks and scope boundaries

1. Default behavior of repeated `agregá leche` must be decided with user-tested scenarios; presence alone does not authorize increment or deduplication.
2. `price` needs role (observation, requirement, preference), unit basis, currency and source. Calculated totals must not be mistaken for observed prices. Experimental `priceTotal` uses JS numbers for a display-only estimate; production monetary arithmetic needs decimal/minor-unit representation and explicit rounding policy.
3. String labels cannot reliably act as product identities. Normalization must not accidentally merge distinct packages or brands.
4. `Item.put` currently has no version checking or atomic multi-record commit. The test reducer does not demonstrate crash-safe replay in IndexedDB.
5. Existing transcript-local merging discards secondary text. Preserve all mention provenance before applying richer state changes.
6. Zero-build PWA constraint argues for JS first. Rust/WASM is optional if a proven reusable CRF or grammar engine brings measurable benefit.
7. The supplied archive omits Listar UI/worker files; browser integration cannot be claimed.

## Implementation order (each step must justify its own complexity)

1. Add an additive `attributes` object to existing Item records, with compatibility adapters. No DB upgrade required unless changing indexes or stores.
2. Introduce a pure `analyze()` with explicit command intents and source evidence; preserve existing `split()` unchanged.
3. Add a pure reducer and unit/price validators, property tests and counterexamples.
4. Introduce versioned, atomic IndexedDB commit and stable operation IDs; test through `fake-indexeddb` and browser reload/retry scenarios.
5. Add context resolver using existing list entries and expose ambiguity in preview.
6. Only then evaluate alternate parsers (Ohm, CRF, Rust/WASM, fine-tuned LLM) on held-out transcripts and selective risk/coverage.

## Explicit result

The full eight-object categorical schema is **not warranted as a storage schema at this stage**. The minimal categorical distinctions that materially improved design are (1) entry identity vs label, (2) observations vs constraints, (3) interpretation vs committed state transition, and (4) immutable state with guarded composition and observational projection laws. Keep the richer schema as a falsifiable reference model, not a runtime dependency.
