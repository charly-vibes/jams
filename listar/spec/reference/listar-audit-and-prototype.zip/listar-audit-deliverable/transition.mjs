// Experimental pure semantic core for Listar. Does not mutate IndexedDB.
// Commands refer to stable item IDs; user-facing NLP and authorization are separate.
const copy = x => structuredClone(x);
export function migrateItem(legacy) { return { ...copy(legacy), attributes: copy(legacy.attributes ?? {}) }; }
export function legacyView(item) { const {attributes, ...legacy} = item; return legacy; }
export function apply(snapshot, command) {
  const state = copy(snapshot);
  if (state.appliedIds?.includes(command.id)) return {ok:true,state, replay:true};
  if (command.expectedVersion !== state.version) return {ok:false,error:'STALE_VERSION'};
  const items = state.items;
  const target = items.find(x => x.id === command.itemId);
  const fail = error => ({ok:false,error});
  if (command.kind === 'query') return {ok:true,state};
  if (command.kind === 'noop') return {ok:true,state};
  if (command.kind === 'create') {
    if (!command.item?.id || items.some(x=>x.id===command.item.id)) return fail('INVALID_CREATE');
    items.push(migrateItem(command.item));
  } else {
    if (!target) return fail('MISSING_TARGET');
    if (command.kind === 'remove') state.items = items.filter(x=>x.id!==command.itemId);
    else if (command.kind === 'set') {
      if (!command.key || !command.value || !['quantity','price','brand','purchased','note'].includes(command.key)) return fail('INVALID_ATTRIBUTE');
      target.attributes ??= {};
      target.attributes[command.key] = copy(command.value);
    } else if (command.kind === 'increment') {
      if (command.key !== 'quantity' || !Number.isFinite(command.by?.value) || command.by.value <= 0) return fail('INVALID_INCREMENT');
      const prior = target.attributes?.quantity ?? {type:'quantity',value:target.quantity,unit:target.unit};
      if (prior.type !== 'quantity' || !Number.isFinite(prior.value) || prior.unit !== command.by.unit) return fail('INCOMPATIBLE_UNITS');
      target.attributes ??= {};
      target.attributes.quantity = {type:'quantity',value:prior.value + command.by.value,unit:prior.unit};
    } else return fail('UNKNOWN_COMMAND');
  }
  state.version++;
  state.appliedIds = [...(state.appliedIds ?? []), command.id];
  return {ok:true,state};
}
export function priceTotal(quantity, price) {
  if (quantity?.type !== 'quantity' || price?.type !== 'price' || price.role !== 'observation' || price.per !== quantity.unit) return null;
  if (!/^\d+(?:\.\d+)?$/.test(price.amount) || !Number.isFinite(quantity.value)) return null;
  // display estimate only, not monetary settlement arithmetic
  return {currency:price.currency, estimated: Number(price.amount)*quantity.value};
}
