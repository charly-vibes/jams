# Validation log — spk 0.12.1 — 2026-10-29

Application source: https://github.com/charly-vibes/jams/tree/main/listar (located, not executed or audited).

## lint

```text
lint: 5 file(s) linted, 0 finding(s), 0 advisory warning(s)
→ Run: specodelic graph
```

## graph

```text
graph: 5 file(s), 79 node(s), 87 edge(s), 0 dangling, 0 typing violation(s), 0 supersedes cycle(s), 0 external boundary(ies)
→ Run: specodelic lint
```

## compile

```text
compile: 5 compiled, 0 failed
  specs/listar-domain.md [listar.domain] → /mnt/data/listar-categorical-specodelic/compiled/listar-domain.toml, /mnt/data/listar-categorical-specodelic/compiled/listar-domain_props.rs, /mnt/data/listar-categorical-specodelic/compiled/listar-domain.tla
  specs/listar-interpretation.md [listar.interpretation] → /mnt/data/listar-categorical-specodelic/compiled/listar-interpretation.toml, /mnt/data/listar-categorical-specodelic/compiled/listar-interpretation_props.rs, /mnt/data/listar-categorical-specodelic/compiled/listar-interpretation.tla
  specs/listar-projections.md [listar.projections] → /mnt/data/listar-categorical-specodelic/compiled/listar-projections.toml, /mnt/data/listar-categorical-specodelic/compiled/listar-projections_props.rs, /mnt/data/listar-categorical-specodelic/compiled/listar-projections.tla
  specs/listar-routing.md [listar.routing] → /mnt/data/listar-categorical-specodelic/compiled/listar-routing.toml, /mnt/data/listar-categorical-specodelic/compiled/listar-routing_props.rs, /mnt/data/listar-categorical-specodelic/compiled/listar-routing.tla
  specs/listar-transition.md [listar.transition] → /mnt/data/listar-categorical-specodelic/compiled/listar-transition.toml, /mnt/data/listar-categorical-specodelic/compiled/listar-transition_props.rs, /mnt/data/listar-categorical-specodelic/compiled/listar-transition.tla
→ Run: specodelic verify (consumes the *_props.rs artifacts)
```

## model-check

```text
model-check: 5 checked, 0 failed
  specs/listar-domain.md [listar.domain]: exploration_only (3 states explored) → /mnt/data/listar-categorical-specodelic/compiled/listar-domain.check.json
    claims: 0 evaluated, 5 unchecked, 0 blocking
      unchecked: assertions_attached, entry_identity, price_context, projection_roundtrip, reference_optional
  specs/listar-interpretation.md [listar.interpretation]: exploration_only (3 states explored) → /mnt/data/listar-categorical-specodelic/compiled/listar-interpretation.check.json
    claims: 0 evaluated, 4 unchecked, 0 blocking
      unchecked: ambiguity_preserved, candidate_evidence, context_scoped, no_direct_mutation
  specs/listar-projections.md [listar.projections]: exploration_only (4 states explored) → /mnt/data/listar-categorical-specodelic/compiled/listar-projections.check.json
    claims: 0 evaluated, 4 unchecked, 0 blocking
      unchecked: codec_roundtrip, derived_not_observed, legacy_retraction, no_price_conflation
  specs/listar-routing.md [listar.routing]: exploration_only (4 states explored) → /mnt/data/listar-categorical-specodelic/compiled/listar-routing.check.json
    claims: 0 evaluated, 5 unchecked, 0 blocking
      unchecked: agreement_not_confidence, optional_models, probability_provenance, reducer_boundary, review_fallback
  specs/listar-transition.md [listar.transition]: exploration_only (4 states explored) → /mnt/data/listar-categorical-specodelic/compiled/listar-transition.check.json
    claims: 0 evaluated, 6 unchecked, 0 blocking
      unchecked: atomic_failure, conditional_commutation, query_identity, referential_integrity, replay_identity, typed_updates
→ Run: specodelic verify (consumes the *.check.json reports)
```

## verify

```text
verify: 0 verified, 5 blocked
  specs/listar-domain.md [listar.domain]: runner_unavailable — the properties gate executes the compiled proptest! blocks and needs the Rust toolchain
      unchecked: assertions_attached, entry_identity, price_context, projection_roundtrip, reference_optional
  specs/listar-interpretation.md [listar.interpretation]: runner_unavailable — the properties gate executes the compiled proptest! blocks and needs the Rust toolchain
      unchecked: ambiguity_preserved, candidate_evidence, context_scoped, no_direct_mutation
  specs/listar-projections.md [listar.projections]: runner_unavailable — the properties gate executes the compiled proptest! blocks and needs the Rust toolchain
      unchecked: codec_roundtrip, derived_not_observed, legacy_retraction, no_price_conflation
  specs/listar-routing.md [listar.routing]: runner_unavailable — the properties gate executes the compiled proptest! blocks and needs the Rust toolchain
      unchecked: agreement_not_confidence, optional_models, probability_provenance, reducer_boundary, review_fallback
  specs/listar-transition.md [listar.transition]: runner_unavailable — the properties gate executes the compiled proptest! blocks and needs the Rust toolchain
      unchecked: atomic_failure, conditional_commutation, query_identity, referential_integrity, replay_identity, typed_updates
verify blocked — the blocking gate, message and hint ride .data.blocked
→ Run: install the Rust toolchain so cargo is on PATH (could not spawn the test runner: No such file or directory (os error 2))
```
