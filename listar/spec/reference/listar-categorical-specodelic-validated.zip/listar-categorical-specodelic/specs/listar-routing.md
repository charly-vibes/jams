---
id: listar.routing
kind: intent
statement: "WHEN candidate interpretations remain uncertain, THE router SHALL select acceptance, model escalation, or review using validated evidence and a separately calibrated risk policy."
---

# listar-routing

The router is an effectful decision policy outside the trusted reducer; models may propose candidates, but cannot commit. A probability is emitted only with an identified calibrator and held-out evaluation. Agreement between models is not itself a probability. Different uncertainty types can route to targeted normalization, CRF, LLM, or immediate user review. Escalation is optional and must improve validated selective risk or correction effort.

## Constraints

| id | kind | expr | traces_to |
| --- | --- | --- | --- |
| probability_provenance | invariant | Numerical correctness probabilities require a named calibration model and evaluation population. | [[listar.routing]] |
| agreement_not_confidence | invariant | Matching outputs do not automatically receive high confidence without empirical evidence. | [[listar.routing]] |
| review_fallback | invariant | Unresolved referents, ambiguous duplicate operations, and incompatible prices can be sent to user review. | [[listar.routing]] |
| reducer_boundary | invariant | The router never directly alters persistent list state. | [[listar.routing]] |
| optional_models | invariant | System remains functional with statistical and generative models disabled. | [[listar.routing]] |

## Model

### States

- `proposed`
- `accepted`
- `escalated`
- `review`

### Transitions

| id | from | to | guard |
| --- | --- | --- | --- |
| accept | proposed | accepted | Acceptance policy is supported by applicable evaluation evidence. [[listar.routing.probability_provenance]] |
| escalate | proposed | escalated | Expected benefit of available next tier exceeds its cost. [[listar.routing.probability_provenance]] |
| abstain | proposed | review | Neither safe acceptance nor useful escalation is justified. [[listar.routing.probability_provenance]] |

## Properties

| id | kind | derives_from | generator | predicate |
| --- | --- | --- | --- | --- |
| test_probability_provenance | unit | [[listar.routing.probability_provenance]] | `fixtures_probability_provenance()` | `oracle_probability_provenance(case)` |
| test_agreement_not_confidence | unit | [[listar.routing.agreement_not_confidence]] | `fixtures_agreement_not_confidence()` | `oracle_agreement_not_confidence(case)` |
| test_review_fallback | unit | [[listar.routing.review_fallback]] | `fixtures_review_fallback()` | `oracle_review_fallback(case)` |
| test_reducer_boundary | unit | [[listar.routing.reducer_boundary]] | `fixtures_reducer_boundary()` | `oracle_reducer_boundary(case)` |
| test_optional_models | unit | [[listar.routing.optional_models]] | `fixtures_optional_models()` | `oracle_optional_models(case)` |

## Verification status

The generator and predicate entries are **named obligations, not executable Specodelic expressions**. The domain laws are implemented in a deliberately smaller independent reference checker under `tests/`, where applicable. CLI validation performed separately; unit property generator/predicate cells remain named placeholders and are not executable law proofs.
