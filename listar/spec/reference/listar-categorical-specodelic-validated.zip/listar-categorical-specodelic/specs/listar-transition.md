---
id: listar.transition
kind: intent
statement: "WHEN a validated command targets a list snapshot, THE reducer SHALL produce a deterministic new state or an explicit rejection without partial mutation."
---

# listar-transition

Reducer delta : State × Command -> Result(State, Error); operation ID and snapshot version are part of the command envelope. Commands include create, set, unset, increment, remove, query and no-op. Attribute arithmetic is permitted only with compatible dimensions, currencies, and bases. Equal versioned inputs yield equal results; independent disjoint updates commute only when their preconditions remain true, excluding concurrent version-check conflicts. Replay of the same committed ID is a no-op (no second increment).

## Constraints

| id | kind | expr | traces_to |
| --- | --- | --- | --- |
| atomic_failure | invariant | Rejected commands leave state, version, and commit log unchanged. | [[listar.transition]] |
| query_identity | invariant | Query and no-op preserve list state and version. | [[listar.transition]] |
| replay_identity | invariant | A previously committed operation ID does not apply again. | [[listar.transition]] |
| typed_updates | invariant | Price and quantity arithmetic requires same compatible type, currency, and physical basis. | [[listar.transition]] |
| conditional_commutation | invariant | Disjoint attribute updates commute at the abstract data-state level if both are applicable and version guards are reconciled. | [[listar.transition]] |
| referential_integrity | invariant | No successfully committed operation creates dangling entry references. | [[listar.transition]] |

## Model

### States

- `proposed`
- `valid`
- `committed`
- `rejected`

### Transitions

| id | from | to | guard |
| --- | --- | --- | --- |
| validate | proposed | valid | The command has valid references, types, preconditions, and snapshot version. [[listar.transition.atomic_failure]] |
| commit | valid | committed | The operation ID is new and all invariants hold atomically. [[listar.transition.atomic_failure]] |
| reject | proposed | rejected | The command fails validation or conflicts with state. [[listar.transition.atomic_failure]] |

## Properties

| id | kind | derives_from | generator | predicate |
| --- | --- | --- | --- | --- |
| test_atomic_failure | unit | [[listar.transition.atomic_failure]] | `fixtures_atomic_failure()` | `oracle_atomic_failure(case)` |
| test_query_identity | unit | [[listar.transition.query_identity]] | `fixtures_query_identity()` | `oracle_query_identity(case)` |
| test_replay_identity | unit | [[listar.transition.replay_identity]] | `fixtures_replay_identity()` | `oracle_replay_identity(case)` |
| test_typed_updates | unit | [[listar.transition.typed_updates]] | `fixtures_typed_updates()` | `oracle_typed_updates(case)` |
| test_conditional_commutation | unit | [[listar.transition.conditional_commutation]] | `fixtures_conditional_commutation()` | `oracle_conditional_commutation(case)` |
| test_referential_integrity | unit | [[listar.transition.referential_integrity]] | `fixtures_referential_integrity()` | `oracle_referential_integrity(case)` |

## Verification status

The generator and predicate entries are **named obligations, not executable Specodelic expressions**. The domain laws are implemented in a deliberately smaller independent reference checker under `tests/`, where applicable. CLI validation performed separately; unit property generator/predicate cells remain named placeholders and are not executable law proofs.
