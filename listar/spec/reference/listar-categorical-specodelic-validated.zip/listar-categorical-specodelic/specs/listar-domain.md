---
id: listar.domain
kind: intent
statement: "THE Listar domain model SHALL distinguish list entries, product references, attribute assertions, and evidence without conflating their identities."
---

# listar-domain

Entries belong to a list and have stable entry IDs. A product reference is optional and never defines entry identity. Multiple entries may reference the same product; duplicate labels do not imply equal entries. Attributes are assertions attached to entries, each with a typed value, semantic role, and optional evidence. A price observation also records currency, price basis, observation time, and optional merchant; it is not an intrinsic product property.

## Constraints

| id | kind | expr | traces_to |
| --- | --- | --- | --- |
| entry_identity | invariant | Distinct entries have distinct stable IDs even when their names or product references coincide. | [[listar.domain]] |
| reference_optional | invariant | An entry may lack a catalog product reference and remains valid. | [[listar.domain]] |
| assertions_attached | invariant | Each assertion references exactly one existing entry; deletion or retention policies must preserve referential integrity. | [[listar.domain]] |
| price_context | invariant | Observed prices carry currency, basis, and contextual source; requirements and estimates are not silently merged into observations. | [[listar.domain]] |
| projection_roundtrip | invariant | Migrating a valid legacy item and projecting its legacy view recovers label, explicit quantity, and unit exactly. | [[listar.domain]] |

## Model

### States

- `draft`
- `well_formed`
- `invalid`

### Transitions

| id | from | to | guard |
| --- | --- | --- | --- |
| validate | draft | well_formed | All references and typed values satisfy the domain schema. [[listar.domain.entry_identity]] |
| reject | draft | invalid | A reference or typed value violates the schema. [[listar.domain.entry_identity]] |

## Properties

| id | kind | derives_from | generator | predicate |
| --- | --- | --- | --- | --- |
| test_entry_identity | unit | [[listar.domain.entry_identity]] | `fixtures_entry_identity()` | `oracle_entry_identity(case)` |
| test_reference_optional | unit | [[listar.domain.reference_optional]] | `fixtures_reference_optional()` | `oracle_reference_optional(case)` |
| test_assertions_attached | unit | [[listar.domain.assertions_attached]] | `fixtures_assertions_attached()` | `oracle_assertions_attached(case)` |
| test_price_context | unit | [[listar.domain.price_context]] | `fixtures_price_context()` | `oracle_price_context(case)` |
| test_projection_roundtrip | unit | [[listar.domain.projection_roundtrip]] | `fixtures_projection_roundtrip()` | `oracle_projection_roundtrip(case)` |

## Verification status

The generator and predicate entries are **named obligations, not executable Specodelic expressions**. The domain laws are implemented in a deliberately smaller independent reference checker under `tests/`, where applicable. CLI validation performed separately; unit property generator/predicate cells remain named placeholders and are not executable law proofs.
