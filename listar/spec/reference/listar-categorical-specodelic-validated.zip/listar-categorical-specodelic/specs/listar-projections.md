---
id: listar.projections
kind: intent
statement: "WHEN Listar changes storage or presentation representations, THE conversion SHALL preserve the declared observable information and reject unsupported loss of meaning."
---

# listar-projections

Define a migration m : Legacy -> New and projection p : New -> Legacy for the legacy-supported subdomain; p ∘ m = identity on that subdomain. Storage codecs encode/decode are inverse up to declared canonicalization. UI previews are projections, not authority to discard ambiguous role/basis/source metadata. Derived line totals are calculations over compatible quantities and prices and are not persisted as authoritative observations.

## Constraints

| id | kind | expr | traces_to |
| --- | --- | --- | --- |
| legacy_retraction | invariant | Projecting a migrated legacy record preserves every legacy-supported field. | [[listar.projections]] |
| codec_roundtrip | invariant | Decode after encode preserves canonical IDs, attribute roles, values, currency, basis, and provenance. | [[listar.projections]] |
| no_price_conflation | invariant | Presentation never changes price observation to requirement, or unit price to total price. | [[listar.projections]] |
| derived_not_observed | invariant | Computed totals remain distinguishable from user-recorded total observations. | [[listar.projections]] |

## Model

### States

- `raw`
- `serialized`
- `restored`
- `invalid`

### Transitions

| id | from | to | guard |
| --- | --- | --- | --- |
| encode | raw | serialized | The item conforms to canonical typed schema. [[listar.projections.legacy_retraction]] |
| decode | serialized | restored | Decode succeeds and preserves supported semantics. [[listar.projections.legacy_retraction]] |
| invalid_data | serialized | invalid | Codec detects unsupported or malformed content. [[listar.projections.legacy_retraction]] |

## Properties

| id | kind | derives_from | generator | predicate |
| --- | --- | --- | --- | --- |
| test_legacy_retraction | unit | [[listar.projections.legacy_retraction]] | `fixtures_legacy_retraction()` | `oracle_legacy_retraction(case)` |
| test_codec_roundtrip | unit | [[listar.projections.codec_roundtrip]] | `fixtures_codec_roundtrip()` | `oracle_codec_roundtrip(case)` |
| test_no_price_conflation | unit | [[listar.projections.no_price_conflation]] | `fixtures_no_price_conflation()` | `oracle_no_price_conflation(case)` |
| test_derived_not_observed | unit | [[listar.projections.derived_not_observed]] | `fixtures_derived_not_observed()` | `oracle_derived_not_observed(case)` |

## Verification status

The generator and predicate entries are **named obligations, not executable Specodelic expressions**. The domain laws are implemented in a deliberately smaller independent reference checker under `tests/`, where applicable. CLI validation performed separately; unit property generator/predicate cells remain named placeholders and are not executable law proofs.
