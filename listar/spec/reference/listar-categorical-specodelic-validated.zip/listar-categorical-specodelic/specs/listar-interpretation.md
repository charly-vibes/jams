---
id: listar.interpretation
kind: intent
statement: "WHEN Listar receives a transcript with context, THE interpreter SHALL preserve supported candidate operations and their evidence without prematurely committing a state change."
---

# listar-interpretation

Interpretation is a relation I : Transcript × Context -> finite set of candidate command sequences, not a single deterministic function. Candidate spans refer to the original transcript; a candidate is not automatically authorized to mutate state. An empty or unknown interpretation is allowed. Candidate order and approximate scores do not constitute calibrated correctness probabilities.

## Constraints

| id | kind | expr | traces_to |
| --- | --- | --- | --- |
| candidate_evidence | invariant | Every inferred item or attribute value retains its supporting source span or explicitly marked inference provenance. | [[listar.interpretation]] |
| ambiguity_preserved | invariant | Distinct plausible operations may coexist; interpretation never silently treats ADD and SET as equivalent. | [[listar.interpretation]] |
| context_scoped | invariant | References are resolved against one versioned snapshot; an exact label match is evidence, not proof of intended action. | [[listar.interpretation]] |
| no_direct_mutation | invariant | Interpreting an utterance cannot change the persistent list state. | [[listar.interpretation]] |

## Model

### States

- `received`
- `candidates`
- `abstained`

### Transitions

| id | from | to | guard |
| --- | --- | --- | --- |
| interpret | received | candidates | At least one candidate is supported by recorded evidence. [[listar.interpretation.candidate_evidence]] |
| abstain | received | abstained | No candidate has adequate evidence or safe resolution. [[listar.interpretation.candidate_evidence]] |

## Properties

| id | kind | derives_from | generator | predicate |
| --- | --- | --- | --- | --- |
| test_candidate_evidence | unit | [[listar.interpretation.candidate_evidence]] | `fixtures_candidate_evidence()` | `oracle_candidate_evidence(case)` |
| test_ambiguity_preserved | unit | [[listar.interpretation.ambiguity_preserved]] | `fixtures_ambiguity_preserved()` | `oracle_ambiguity_preserved(case)` |
| test_context_scoped | unit | [[listar.interpretation.context_scoped]] | `fixtures_context_scoped()` | `oracle_context_scoped(case)` |
| test_no_direct_mutation | unit | [[listar.interpretation.no_direct_mutation]] | `fixtures_no_direct_mutation()` | `oracle_no_direct_mutation(case)` |

## Verification status

The generator and predicate entries are **named obligations, not executable Specodelic expressions**. The domain laws are implemented in a deliberately smaller independent reference checker under `tests/`, where applicable. CLI validation performed separately; unit property generator/predicate cells remain named placeholders and are not executable law proofs.
