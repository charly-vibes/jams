# Listar — categorical modeling + Specodelic pack

Generated 2026-10-28 (research design revision). **Checked with `spk` v0.12.1 on 2026-10-29; lint/graph/compile/model-check successful; verify blocked.** The original prior pack was a state-machine draft; this revision distinguishes entities, relations, behavioral laws, and counterexamples. Source format: Specodelic Intent/Constraints/Model/Properties as documented in published source; differences across releases need checking.

## Contents

- `MODEL.md`: category-theoretic modeling attempt, finite relational schema, explicit equations and conditional laws, eleven counterexamples.
- `specs/`: five four-layer documents (`listar-domain`, `listar-interpretation`, `listar-transition`, `listar-projections`, `listar-routing`).
- `scenarios.jsonl`: input/candidate/expected semantic test cases.
- `tests/reference_checks.py`: runnable independent Python reference tests for a subset of laws; this is **not a Specodelic checker**.

## Key decision

`(transcript, context, snapshot) → candidate commands → selection/review → validated reducer`. List entries are not identical to products. Store-specific/time-specific prices are assertions (observations or constraints), not product fields. `parse` and `resolve` never mutate. Multiple candidates may remain unresolved.

## Model laws

State changes compose as partial/effectful operations with errors; conditional disjoint commutation is tested on the data projection (audit log and version order differ). Legacy migration has a left inverse on its supported domain, not a two-way isomorphism with enriched items. Optional product references mean the domain graph is a draft *partial* schema, not a certified ACSet.

## Validation and limitations

1. `python3 tests/reference_checks.py` runs reference counterexample/law tests.
2. Install `spk` **version 0.12.1** from its verified official release, then check `spk --help` for precise subcommand usage.
3. Run lint/compile/model-check/verify where supported; record release, command output, and required changes.
4. Property table predicates and generators are placeholders naming executable obligations, **not compilation-ready Rust, TLA+, or proptest code**. A CLI lint success would not prove these semantic properties.

Known limitations: semantic properties remain unchecked (24 claims); model checking explored only small abstract state machines. `spk verify` is blocked because the Rust toolchain (`cargo`) is unavailable. No executable categorical proof has been established. The actual Listar app is located at https://github.com/charly-vibes/jams/tree/main/listar ; its source was not available for execution in this environment. The sample checker establishes only its own explicit example tests, not comprehensive correctness.

## Actual CLI results (2026-10-29)

- `spk lint specs`: 5 files, 0 findings, 0 warnings.
- `spk graph specs`: exit 0.
- `spk compile specs --out-dir compiled`: 5 compiled, 0 failed.
- `spk model-check specs --out-dir compiled`: 5 checked, 0 failed; `exploration_only`, 24 claims unchecked.
- `spk verify specs --out-dir compiled`: 5 blocked; Rust toolchain unavailable.
- `python3 tests/reference_checks.py`: 10 reference example checks passed (not formal proofs).

See `VALIDATION.md` for recorded output and commands.
