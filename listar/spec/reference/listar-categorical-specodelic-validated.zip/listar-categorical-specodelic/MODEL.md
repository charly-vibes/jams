# Listar — categorical domain model (design, not a claimed proof)

## Objective and minimality

Distinguish **List**, **Entry**, **ProductRef**, **Assertion**, **Evidence**, **Command**, **Snapshot**, and **Candidate** only where counterexamples require it. Do not force the runtime to use category theory or ACSet libraries. Implement the smallest relations needed by the validated scenarios.

## Schema as a directed graph / finite presentation

**Objects:** List L, Entry E, Product P, Assertion A, Evidence V, Candidate C, Command O, Snapshot S.

**Total arrows:** `entryList:E→L`, `assertionEntry:A→E`, `commandSnapshot:O→S`, `candidateSnapshot:C→S`, `candidateEvidence:C→P_f(V)` (finite set of evidence references), `candidateOperations:C→Seq(O)`.

**Optional arrows (represented by partial maps or explicit option type):** `entryProduct:E⇀P`, `assertionEvidence:A⇀V`, `commandTarget:O⇀E` (create commands have no existing target).

**Attributes / typed columns:** `entryId:E→ID`, `label:E→Text`, `assertionKey:A→AttributeKey`, `assertionRole:A→{observation,requirement,preference,state}`, `assertionValue:A→TypedValue`, `snapshotVersion:S→Version`, `evidenceSpan:V→Span?` and `evidenceSource:V→Source`. Price observations are structured typed values `{amountDecimal,currency,basis,observedAt?,merchant?}`, not a universal intrinsic price attached to P.

**Equations / constraints:** Each entry has exactly one owning list; each assertion has exactly one parent entry. `entryId` is injective within a list snapshot. Evidence spans must lie within the originating transcript. A candidate's operations must reference the same snapshot version as the candidate, except for a deliberately typed rebase operation. All references must resolve or be explicitly unresolved.

This is a *candidate schema*, not yet a formal ACSet declaration; optional arrows, higher-order candidate collections, and typed attributes must be encoded appropriately before use in AlgebraicJulia or any categorical database library.

## Fundamental semantic distinction

- Entry = user's occurrence in a particular list. Two entries may point to the same product.
- ProductRef = optional canonical/catalog identity, not required for free-form input.
- Assertion = an attributed claim or constraint on an entry, including who/when/why if available.
- Price = observation, intended/maximum price constraint, or derived value, never an unqualified scalar.
- Candidate = hypothesis about user intent; operation = proposed state transition; commit = separate authorized effect.

## Operations as arrows

For a state type S and explicit error type E, a validated command determines a partial state transition `δ_o : S → Result(S,E)`. With Kleisli-style error propagation, operations compose when the first succeeds; identity is no-op. The category is not the category of all state endofunctions without accounting for errors, guards, and version checks.

**Laws to test (stated at the appropriate observational level):**

1. `δ_noop(s) = Ok(s)` (state identity; audit metadata may differ only if explicitly outside state).
2. `δ_query(s) = Ok(s)` (read-only).
3. `δ_o(s) = Err(e) ⇒ s_after = s` (atomic failure).
4. If `o.id` was committed, replay yields the same snapshot, not a second effect.
5. For operations on disjoint attributes, under stable preconditions and ignoring operation order in the *abstract data projection*, `δ_b(δ_a(s)) ≡ δ_a(δ_b(s))`; not necessarily equal in audit-log order or with the same optimistic version token.
6. `legacyView(migrate(x)) = x` for valid legacy records (retraction on the supported subdomain). `migrate(legacyView(y)) = y` is **not** claimed for enriched records.
7. `decode(encode(s)) ≡ s` for supported canonical values, including evidence and semantic roles.
8. Interpretation is a multivalued relation `I : Transcript × Context → P_f(Candidate)`, not assumed functorial or probabilistically calibrated.
9. `preview` must expose materially different commands or state changes; it is not required to be injective on all internal metadata, but cannot silently hide distinctions needed for user authorization.

## Counterexamples that force structure

| Example | Naive design fails because | Needed distinction |
| --- | --- | --- |
| Two identical `leche` rows | label is not identity | Entry ID ≠ label/product |
| Milk in two stores at distinct prices | `product.price` overwrites history/context | Price assertion + context |
| "no más de 2000" vs "sale 2000" | numeric price conflates constraint and observation | Assertion role |
| "otro litro" after milk exists | parser cannot know operation from new item alone | Command + current snapshot |
| "poné dos litros" after 1 L | set and increment have different semantics | Explicit operation type |
| Retried increment after app crash | same request applied twice | Stable operation ID + commit log |
| State changed after speech started | candidate targets outdated list | Snapshot version + re-evaluation |
| "leche, no, yogur" | token labels alone don't preserve replacement scope | Multiple interpretations + evidence |
| `2 kg` × `1500 ARS/package` | incompatible units yield fictitious total | Dimensional price basis |
| Copy migration into new schema | projecting enriched item loses context | One-way retraction, not equivalence |
| Two models agree on wrong parse | model consensus not correctness probability | Calibrated outcome model |

## Explicit non-goals

No category-theoretic jargon is required in product code. No mandatory ACSet, ontology, provenance database, store catalog, event sourcing, CRF, LLM, or Rust/WASM. Introduce each only if tests establish incremental value. Open unknowns include cross-list sharing, deletion retention, attribute conflict policy, price-source trust, multiple quantities per entry, and user-authorized automatic merging.

## Falsifiable simplification test

Compare this schema against `{id,label,attributes}` under a frozen scenario corpus. Retain separate ProductRef and Assertion objects only if they eliminate observable failures or meaningfully reduce special-case code. Measure total concepts, transformation paths, error rate, and number of exceptions; reverting to simpler model is a valid result.
