"""Independent executable examples for categorical Listar design laws; NOT spk validation."""
import copy, json, pathlib

def migrate(x):
    attrs = {}
    if x.get('quantity') is not None:
        attrs['quantity'] = {'value':str(x['quantity']), 'unit':x.get('unit')}
    return {'id':x['id'], 'label':x['label'], 'attributes':attrs, 'assertions':[]}

def legacy_view(x):
    result = {'id':x['id'], 'label':x['label']}
    if 'quantity' in x['attributes']:
        result['quantity'] = int(x['attributes']['quantity']['value'])
        result['unit'] = x['attributes']['quantity']['unit']
    return result

def apply(state, op):
    s=copy.deepcopy(state)
    if op['id'] in s['committed']: return s
    if op['version'] != s['version']: raise ValueError('stale')
    if op['type'] in ('noop','query'): return s
    if op['type']!='set': raise ValueError('unsupported')
    target=op['target']
    if target not in s['items']: raise ValueError('missing')
    if op['attribute']=='price' and op['value'].get('basis') not in ('kg','L','item','package','total'):
        raise ValueError('invalid basis')
    s['items'][target][op['attribute']]=op['value']
    s['version']+=1
    s['committed'].append(op['id'])
    return s

def check():
    legacy={'id':'i1','label':'papa','quantity':2,'unit':'kg'}
    assert legacy_view(migrate(legacy))==legacy
    enriched=migrate(legacy)
    enriched['assertions'].append({'role':'observation','price':{'amount':'1500','currency':'ARS','basis':'kg'}})
    assert legacy_view(enriched)==legacy
    assert enriched != migrate(legacy_view(enriched)) # not a two-way isomorphism
    assert json.loads(json.dumps(enriched))==enriched
    state={'version':0,'committed':[],'items':{'i1':{'label':'leche','qty':1}}}
    assert apply(state,{'id':'q','version':0,'type':'query'})==state
    a={'id':'a','version':0,'type':'set','target':'i1','attribute':'brand','value':'X'}
    after=apply(state,a)
    assert after['items']['i1']['brand']=='X' and state['items']['i1'].get('brand') is None
    assert apply(after,a)==after # replay identity
    try: apply(after,{'id':'b','version':0,'type':'set','target':'i1','attribute':'brand','value':'Y'})
    except ValueError as ex: assert str(ex)=='stale'
    else: raise AssertionError('expected stale rejection')
    assert after['items']['i1']['brand']=='X' # atomic error
    # Disjoint updates commute in data projection if their versions are rebased.
    def ordered(names):
        s=copy.deepcopy(state)
        for i,(name,val) in enumerate(names):
            s=apply(s,{'id':f'op{i}-{name}','version':s['version'],'type':'set','target':'i1','attribute':name,'value':val})
        return s['items']
    assert ordered([('brand','X'),('purchased',True)])==ordered([('purchased',True),('brand','X')])
    assert {'role':'observation','value':2000} != {'role':'requirement','value':2000}
    assert {'basis':'kg','amount':'1500'} != {'basis':'package','amount':'1500'}
    # Entries are distinct even if labels coincide.
    assert len({'i1':'leche','i2':'leche'})==2
    print('PASS: 10 reference law/counterexample checks (not spk verification)')

if __name__=='__main__': check()
